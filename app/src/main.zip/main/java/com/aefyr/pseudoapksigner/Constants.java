package com.aefyr.pseudoapksigner;

public class Constants {
    static final String LINE_ENDING = "\r\n";
    static final String GENERATOR_NAME = "Android Gradle 8.0.2";
    public static final String UTF8 = "UTF-8";
    public static final String UTF16 = "UTF-16LE";
}
