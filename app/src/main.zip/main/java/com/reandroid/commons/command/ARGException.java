package com.reandroid.commons.command;

public class ARGException extends Exception{
    public ARGException(String msg){
        super(msg);
    }
}